#include<iostream>
#include<string.h>
#include<fstream>
#include<cstdlib>
#include<ctime>
#include<conio.h>
#include<windows.h>
using namespace std;

#define max 100

void start()
{
	system("color F0");
	system("cls");
	cout<<"\n\t\t\t--------------------------";
	cout<<"\n\t\t\t* HOTEL MANAGEMENT SYSTEM *";
	cout<<"\n\t\t\t--------------------------";
	Sleep(500);
      cout<<"\n\n\n\n\t\tMade By:";
	Sleep(500);
      cout<<"\tAli mazareyan";
	Sleep(500);
     cout<<"\n\n\t\tSubmitted To:";
	Sleep(500);
     cout<<"\tMrs.Nikookar";
	Sleep(500);
    cout<<"\n\n\n\n\t\tPress any key to continue....!!";
		getch();
		
		system("cls");
}

bool IsloggedIn()
{
	string username,password,un,pw;
	
	cout<<"//************ Login ************//"<<endl;
	cout<<"Enter your username: ";
	cin>>username;
	cout<<"Enter your password: ";
	cin>>password;
	
	ifstream read("Login.txt");
	getline(read,un);
	getline(read,pw);
	
	if(un == username && pw == password)
	{
		return true;
	}
	else
	{
		return false;
	}
}

int randrange(int min , int maxi)
{
	srand(time(0));
	return (rand() % (maxi - min)) + min;
}

int rand_update(int mn , int mx)
{
	srand(time(0));
	return (rand() % (mx - mn)) + mn;
}

int follow_up_num(int mi , int ma)
{
	srand(time(0));
	return (rand() % (mi - ma)) + mi;	
}

void forgot()
{
	int ch;
	system("cls");
	cout<<"1.Search your account by Username ";
	cout<<"\n2.Search your account by Password ";
	cout<<"\n3.Mainmenu ";
	cout<<"\nEnter your choice : ";
	cin>>ch;
	
	switch(ch)
	{
			case 1:
			{
				int ex = 0;
				string searchuser,su,sp;
				cout<<"Enter your remembered username :";
				cin>>searchuser;
				
				ifstream searchu("Reception.txt");
				while(searchu>>su>>sp)
				{
					if(su == searchuser)
					{
						ex = 1;
						break;
					}
				}
				searchu.close();
				if(ex == 1)
				{
					cout<<"Account found !\n";
					cout<<"Your password is "<<sp;
					cout<<"Your username is "<<su;
					cin.get();
					cin.get();
					forgot(); 
				}
				else
				{
					cout<<"Sorry, your account is not found \n";
					cin.get();
					cin.get();
					forgot();
				}
				break;
			}
			case 2:
			{
			int exi = 0;
			string searchpass,su2,ps2;
			cout<<"Enter the remembered password :";
			cin>>searchpass;
			
			ifstream searchp("Manager.txt");
			while(searchp>>su2>>ps2)
			{
				if(ps2 == searchpass)
				{
					exi = 1;
					break;
				}
			}
			searchp.close();
			if(exi == 1)
			{
				cout<<"hurry ! the account found \n";
				cout<<"Your username is :"<<su2;
				cout<<"\nYour password is :"<<ps2;
				cin.get();
				cin.get();
				forgot();
			}
				break;
			}
		case 3:
			{
			forgot();
				break;
			}
			default:
			{
				cout<<"you have given a wrong choice. press a key to try again.\n";
				cin.get();
				cin.get();
				forgot();
			}
	}
}

class Customer
{
	public:
		char name[100];
		char address[100];
		char phone[12];
		char from_date[20];
		char to_date[20];
		float payment_advance;
		int booking_id;
};

class Employee
{
	public :
	char name[100];
	char f_name[100];
	char phone[100];
	char job_sub[100];
	char id[10];
	float salary;
	
	void get_sataff();
	void update_emp();
	void show_list();
};

class Room
{	
	public:
		char type;
		char stype;
		char ac;
		int roomNumber;
		int rent;
		int status;

		class Customer cust;
		class Room addRoom(int);
		void deleteRoom(int);
		void displayRoom(Room);
};
//Global Declarations
class Room rooms[max];
int count=0;

Room Room::addRoom(int rno)
{
	class Room room;
		room.roomNumber=rno;
		cout<<"\nType AC/Non-AC (AC/Non-AC) : ";
		cin>>room.ac;
		cout<<"\nType Comfort (S/N) : ";
		cin>>room.type;
		cout<<"\nType Size (Big/Small) : ";
		cin>>room.stype;
		cout<<"\nDaily Rent : ";
		cin>>room.rent;
		room.status=0;

cout<<"\n Room Added Successfully!";
getch();
return room;
}

void Room::displayRoom(Room tempRoom)
{
	fstream file("Display Room.txt",ios::out);
	if(!file){
		cout<<"File not found..."<<endl;
	}else
	{
	file<<"Room Number: \t"<<tempRoom.roomNumber;
	file<<"\nType AC/Non-AC (A/N) "<<tempRoom.ac;
	file<<"\nType Comfort (S/N) "<<tempRoom.type;
	file<<"\nType Size (B/S) "<<tempRoom.stype;
	file<<"\nRent: "<<tempRoom.rent;
	file.close();
	}
	cout<<"\nRoom Number: \t"<<tempRoom.roomNumber;
	cout<<"\nType AC/Non-AC (A/N) "<<tempRoom.ac;
	cout<<"\nType Comfort (S/N) "<<tempRoom.type;
	cout<<"\nType Size (B/S) "<<tempRoom.stype;
	cout<<"\nRent: "<<tempRoom.rent;
}

class HotelMgnt:protected Room
{
	public:
	void checkIn();
	void checkInG();
	void Edit_Record();
	void Edit_Record_Guest();
	void getAvailRoom();
	void searchCustomer(char *);
	void checkOut(int);
	void checkOutG(int);
	void guestSummaryReport();
};

void HotelMgnt::guestSummaryReport()
{
	if(count==0)
		{
			cout<<"\n No Guest in Hotel !!";
		}	
	for(int i=0;i<count;i++)
		{
			if(rooms[i].status==1)
				{
					cout<<"\n Customer First Name : "<<rooms[i].cust.name;
					cout<<"\n Room Number : "<<rooms[i].roomNumber;
					cout<<"\n Address (only city) : "<<rooms[i].cust.address;
					cout<<"\n Phone : "<<rooms[i].cust.phone;
					cout<<"\n---------------------------------------";	
				}
		}
	getch();
	
	system("cls");
	
}

void HotelMgnt::checkIn()
{
	int i,found=0,rno;
	
	class Room room;
	cout<<"\nEnter Room number : ";
	cin>>rno;
	for(i=0;i<count;i++)
		{
			if(rooms[i].roomNumber==rno)
			{
			found=1;
			break;
			}
		}
	if(found==1)
	{
		if(rooms[i].status==1)
			{
				cout<<"\nRoom is already Booked";
				getch();
				return;
			}
		fstream file;
		file.open("Check IN.txt",ios::in|ios::out|ios::app);
		cout<<"\nYour Booking ID: ";
		
		cout<<follow_up_num(99999, 1000000)<<endl;
		
		cout<<"\nEnter Customer Name (First Name): ";
		cin>>rooms[i].cust.name;
		
		cout<<"\nEnter Address (only city): ";
		cin>>rooms[i].cust.address;
		
		cout<<"\nEnter Phone: ";
		cin>>rooms[i].cust.phone;
		
		cout<<"\nEnter From Date: ";
		cin>>rooms[i].cust.from_date;
		
		cout<<"\nEnter to  Date: ";
		cin>>rooms[i].cust.to_date;
		
		cout<<"\nEnter Advance Payment: ";
		cin>>rooms[i].cust.payment_advance;
		
		file<<"Booking ID :"<<follow_up_num(99999, 1000000)<<"\nCustomer Name :"<<rooms[i].cust.name<<"\nAddress :"<<rooms[i].cust.address<<"\nPhone Number :"<<rooms[i].cust.phone<<"\nEnter to  Date :"<<rooms[i].cust.from_date<<" to "<<rooms[i].cust.to_date<<"\nPayment :"<<rooms[i].cust.payment_advance;
		file.close();
		
		rooms[i].status=1;
		
		cout<<"\n Customer Checked-in Successfully..";
	getch();
	}
	
	system("cls");
	
}

void HotelMgnt::checkInG()
{
	int i,found=0,rno;
	
	class Room room;
	cout<<"\nGuest Booking Room";
	cout<<"\nEnter Room number : ";
	cin>>rno;
	for(i=0;i<count;i++)
		{
			if(rooms[i].roomNumber==rno)
			{
			found=1;
			break;
			}
		}
	if(found==1)
	{
		if(rooms[i].status==1)
			{
				cout<<"\nRoom is already Booked";
				getch();
				return;
			}
		fstream file;
		file.open("Check-IN-G.txt",ios::in|ios::out|ios::app);
		cout<<"\nEnter Booking ID: ";
		cin>>rooms[i].cust.booking_id;
		
		cout<<"\nEnter Customer Name (First Name): ";
		cin>>rooms[i].cust.name;
		
		cout<<"\nEnter Address (only city): ";
		cin>>rooms[i].cust.address;
		
		cout<<"\nEnter Phone: ";
		cin>>rooms[i].cust.phone;
		
		cout<<"\nEnter From Date: ";
		cin>>rooms[i].cust.from_date;
		
		cout<<"\nEnter to  Date: ";
		cin>>rooms[i].cust.to_date;
		
		
		cout<<"\nEnter Advance Payment: ";
		cin>>rooms[i].cust.payment_advance;
		
		file<<"Guest Booking Room"<<"\nBooking ID :"<<rooms[i].cust.booking_id<<"\nCustomer Name :"<<rooms[i].cust.name<<"\nAddress :"<<rooms[i].cust.address<<"\nPhone Number :"<<rooms[i].cust.phone<<"\nEnter to  Date :"<<rooms[i].cust.from_date<<" to "<<rooms[i].cust.to_date<<"\nPayment :"<<rooms[i].cust.payment_advance;
		file.close();
		
		rooms[i].status=1;
		
		cout<<"\n Customer Checked-in Successfully..";
	getch();
	}
	
	system("cls");
	
}

void HotelMgnt::getAvailRoom()
{
	int i,found=0;
	for(i=0;i<count;i++)
	{
		if(rooms[i].status==0)
		{
			displayRoom(rooms[i]);
			cout<<"\n\nPress enter for next room"<<endl;
			found=1;
			getch();
		}
	}
	if(found==0)
	{
		cout<<"\nAll rooms are reserved";
		getch();
	}
	system("cls");
}

void HotelMgnt::searchCustomer(char *pname)
{
	int i,found=0;
	for(i=0;i<count;i++)
	{
		if(rooms[i].status==1 && stricmp(rooms[i].cust.name,pname)==0)
		{
			cout<<"\nCustomer Name: "<<rooms[i].cust.name;
			cout<<"\nRoom Number: "<<rooms[i].roomNumber;
			
			cout<<"\n\nPress enter for next record";
			found=1;
		getch();
		}
	}
	if(found==0)
	{
		cout<<"\nPerson not found.";
	getch();
	}
	
	system("cls");
	
}

void HotelMgnt::checkOut(int roomNum)
{
	
	int i,found=0,days,rno;
	float billAmount=0;
	for(i=0;i<count;i++)
		{
			if(rooms[i].status==1 && rooms[i].roomNumber==roomNum)
			{
			rno = rooms[i].roomNumber;
			found=1;
			getch();
			break;
			}
		}
	if(found==1)
	{
		cout<<"\nEnter Number of Days:\t";
		cin>>days;
		billAmount=days * rooms[i].rent;
		
		cout<<"\n######## CheckOut Details ########\n";
		cout<<"\nBooking Number :"<<follow_up_num(99999, 1000000);
		cout<<"\nCustomer Name : "<<rooms[i].cust.name;
		cout<<"\nRoom Number : "<<rooms[i].roomNumber;
		cout<<"\nAddress : "<<rooms[i].cust.address;
		cout<<"\nPhone : "<<rooms[i].cust.phone;
		cout<<"\nTotal Amount Due : "<<billAmount<<" /";
		cout<<"\nAdvance Paid: "<<rooms[i].cust.payment_advance<<" /";
		cout<<"\n*** Total Payable: "<<billAmount-rooms[i].cust.payment_advance<<"/ only"<<endl;
		
		fstream file;
		file.open("Check-Out.txt",ios::in|ios::out|ios::app);
		file<<"\n######## Check-Out-Guest Details ########\n";
		file<<"\nBooking Number :"<<follow_up_num(99999, 1000000);
		file<<"\nCustomer Name : "<<rooms[i].cust.name;
		file<<"\nRoom Number : "<<rooms[i].roomNumber;
		file<<"\nAddress : "<<rooms[i].cust.address;
		file<<"\nPhone : "<<rooms[i].cust.phone;
		file<<"\nTotal Amount Due : "<<billAmount<<" /";
		file<<"\nAdvance Paid: "<<rooms[i].cust.payment_advance<<" /";
		file<<"\n*** Total Payable: "<<billAmount-rooms[i].cust.payment_advance<<"/ only"<<endl;
		file.close();
	
	rooms[i].status=0;
	}
	getch();
	system("cls");
}

void HotelMgnt::checkOutG(int roomNum)
{
	int i,found=0,days,rno;
	float billAmount=0;
	for(i=0;i<count;i++)
		{
			if(rooms[i].status==1 && rooms[i].roomNumber==roomNum)
			{
			rno = rooms[i].roomNumber;
			found=1;
			getch();
			break;
			}
		}
	if(found==1)
	{
		cout<<"\nEnter Number of Days:\t";
		cin>>days;
		billAmount=days * rooms[i].rent;
		
		cout<<"\n######## Check-Out-Guest Details ########\n";
		cout<<"\nYour Booking ID : "<<rooms[i].cust.booking_id;
		cout<<"\nCustomer Name : "<<rooms[i].cust.name;
		cout<<"\nRoom Number : "<<rooms[i].roomNumber;
		cout<<"\nAddress : "<<rooms[i].cust.address;
		cout<<"\nPhone : "<<rooms[i].cust.phone;
		cout<<"\nTotal Amount Due : "<<billAmount<<" /";
		cout<<"\nAdvance Paid: "<<rooms[i].cust.payment_advance<<" /";
		cout<<"\n*** Total Payable: "<<billAmount-rooms[i].cust.payment_advance<<"/ only"<<endl;
	
		fstream file;
		file.open("Check-Out-G.txt",ios::in|ios::out|ios::app);
		file<<"\n######## Check-Out-Guest Details ########\n";
		file<<"\nYour Booking ID: "<<rooms[i].cust.booking_id;
		file<<"\nCustomer Name : "<<rooms[i].cust.name;
		file<<"\nRoom Number : "<<rooms[i].roomNumber;
		file<<"\nAddress : "<<rooms[i].cust.address;
		file<<"\nPhone : "<<rooms[i].cust.phone;
		file<<"\nTotal Amount Due : "<<billAmount<<" /";
		file<<"\nAdvance Paid: "<<rooms[i].cust.payment_advance<<" /";
		file<<"\n*** Total Payable: "<<billAmount-rooms[i].cust.payment_advance<<"/ only"<<endl;
		file.close();
	rooms[i].status=0;
	}
	getch();
	system("cls");
}

void HotelMgnt::Edit_Record()
{
	Room room;
	fstream bfile;
	bfile.open("Check IN.txt",ios::in|ios::out|ios::app);
	cout<<"\nINPUT Booking ID to modify : "<<endl;
	cin>>room.cust.booking_id;
	if(!bfile)
	{
		cout<<"file couldn't be opened. product ID not found. \n";
	}
	cout<<"\nEnter your New ID: ";
	cin>>room.cust.booking_id;
	cout<<"\nEnter Customer New Name (First Name): ";
	cin>>room.cust.name;
	cout<<"\nEnter New Address (only city): ";
	cin>>room.cust.address;
	cout<<"\nEnter New Phone: ";
	cin>>room.cust.phone;
	cout<<"\nEnter From Date: ";
	cin>>room.cust.from_date;
	cout<<"\nEnter to  Date: ";
	cin>>room.cust.to_date;
	cout<<"\nEnter Advance Payment: ";
	cin>>room.cust.payment_advance;
	bfile<<"\nCustomer Booking"<<"Booking ID :"<<room.cust.booking_id<<"\nCustomer Name :"<<room.cust.name<<"\nAddress :"<<room.cust.address<<"\nPhone Number :"<<room.cust.phone<<"\nEnter to  Date :"<<room.cust.from_date<<" to "<<room.cust.to_date<<"\nPayment :"<<room.cust.payment_advance;
	bfile.close();
	
	system("cls");
}

void HotelMgnt::Edit_Record_Guest()
{
	Room room;
	fstream dfile;
	dfile.open("Check-IN-G.txt",ios::in|ios::out);
	cout<<"\nINPUT Booking ID to modify : "<<endl;
	cin>>room.cust.booking_id;
	if(!dfile)
	{
		cout<<"file couldn't be opened. product ID not found. \n";
	}
	cout<<"\nEnter your New ID: ";
	cin>>room.cust.booking_id;
	cout<<"\nEnter Customer New Name (First Name): ";
	cin>>room.cust.name;
	cout<<"\nEnter New Address (only city): ";
	cin>>room.cust.address;
	cout<<"\nEnter New Phone: ";
	cin>>room.cust.phone;
	cout<<"\nEnter From Date: ";
	cin>>room.cust.from_date;
	cout<<"\nEnter to  Date: ";
	cin>>room.cust.to_date;
	cout<<"\nEnter Advance Payment: ";
	cin>>room.cust.payment_advance;
	dfile<<"\nGuest Booking"<<"Booking ID :"<<room.cust.booking_id<<"\nCustomer Name :"<<room.cust.name<<"\nAddress :"<<room.cust.address<<"\nPhone Number :"<<room.cust.phone<<"\nEnter to  Date :"<<room.cust.from_date<<" to "<<room.cust.to_date<<"\nPayment :"<<room.cust.payment_advance;
	dfile.close();
	
	system("cls");
}

void Employee::get_sataff()
{
	int s;
	cout<<" 1 : Reception"<<endl;
	cout<<" 2 : Security"<<endl;
	cout<<" 3 : Cleaning"<<endl;
	cout<<"Please enter your rule"<<endl;
	cin>>s;
	switch (s)
	{
		case 1:
			{
				cout<<"\nEnter name : ";
				cin>>name;
				cout<<"\nEnter Family name : ";
				cin>>f_name;
				cout<<"\nEnter Phone Number : ";
				cin>>phone;
				cout<<"\nEnter Salary : ";
				cin>>salary;
				cout<<"\nID : ";
				cout<<randrange(99999, 1000000);
				fstream file;
				file.open("Receptions.txt",ios::in|ios::out|ios::app);
				file<<"Name\t"<<name;
				file<<"\nFamily name\t"<<f_name;
				file<<"\nPhone Number\t"<<phone;
				file<<"\nSalary\t"<<salary;
				file<<"\nID\t"<<randrange(99999, 1000000)<<endl;
				file.close();

				system("cls");

				break;
			}
		case 2:
			{
				cout<<"\nEnter name : ";
				cin>>name;
				cout<<"\nEnter Family name : ";
				cin>>f_name;
				cout<<"\nEnter Phone Number : ";
				cin>>phone;
				cout<<"\nEnter Salary : ";
				cin>>salary;
				cout<<"\nEnter ID : ";
				cout<<randrange(99999, 1000000);
				fstream f;
				f.open("Security.txt",ios::in|ios::out|ios::app);
				f<<"Name\t"<<name;
				f<<"\nFamily name\t"<<f_name;
				f<<"\nPhone Number\t"<<phone;
				f<<"\nSalary\t"<<salary;
				f<<"\nID\t"<<randrange(99999, 1000000)<<endl;
				f.close();

				system("cls");

				break;
			}
		case 3:
			{
				cout<<"\nEnter name : ";
				cin>>name;
				cout<<"\nEnter Family name : ";
				cin>>f_name;
				cout<<"\nEnter Phone Number : ";
				cin>>phone;
				cout<<"\nEnter Salary : ";
				cin>>salary;
				cout<<"\nEnter ID : ";
				cout<<randrange(99999, 1000000);
				fstream fi;
				fi.open("Cleaning.txt",ios::in|ios::out|ios::app);
				fi<<"Name\t"<<name;
				fi<<"\nFamily name\t"<<f_name;
				fi<<"\nPhone Number\t"<<phone;
				fi<<"\nSalary\t"<<salary;
				fi<<"\nID\t"<<randrange(99999, 1000000)<<endl;
				fi.close();

				system("cls");

				break;
			}

		default :
			{
				cout<<"Invalid Option !!!"<<endl;
				break;
			}
	}
	
	system("cls");

}

void Employee::update_emp()
{
	int a;
	cout<<" 1 : Reception"<<endl;
	cout<<" 2 : Security"<<endl;
	cout<<" 3 : Cleaning"<<endl;
	cout<<"Please enter your rule"<<endl;
	cin>>a;

	switch (a)
	{
		case 1:
			{
				fstream file;
				file.open("Receptions.txt",ios::in|ios::out);
				cout<<"\nINPUT employee ID to modify: "<<endl;
    			cin>>id;

    			if(!file)
				    {
				    	cout<<"file couldn't be opened. product ID not found. \n";
					}
					cout<<"Modify employee name : ";
				  	cin>>name;
				  	cout<<"\nEModify Family name : ";
					cin>>f_name;
					cout<<"\nModify Phone Number : ";
					cin>>phone;
					cout<<"\nModify Salary : ";
					cin>>salary;
					cout<<"\nModify ID : ";
					cout<<rand_update(99999, 1000000);
				  	file<<"\nName : "<<name<< "\nFamily name : "<<f_name<<"\nPhone Number : "<<phone<<"\nSalary : "<<salary<<"\nID"<<rand_update(99999, 1000000)<<endl;
				file.close();
				 	system("cls");

				break;
			}
		case 2:
			{
				fstream f;
				f.open("Security.txt",ios::in|ios::out);
				cout<<"\nINPUT employee ID to modify: "<<endl;
    			cin>>id;

    			if(!f)
				    {
				    	cout<<"file couldn't be opened. product ID not found. \n";
					}
					cout<<"Modify employee name : ";
				  	cin>>name;
				  	cout<<"\nEModify Family name : ";
					cin>>f_name;
					cout<<"\nModify Phone Number : ";
					cin>>phone;
					cout<<"\nModify Salary : ";
					cin>>salary;
					cout<<"\nModify ID : ";
					cout<<rand_update(99999, 1000000);
				  	f<<"\nName : "<<name<< "\nFamily name : "<<f_name<<"\nPhone Number : "<<phone<<"\nSalary : "<<salary<<"\nID"<<rand_update(99999, 1000000)<<endl;
				f.close();
				 	system("cls");

				break;
			}
		case 3:
			{
				fstream fi;
				fi.open("Security.txt",ios::in|ios::out);
				cout<<"\nINPUT employee ID to modify: "<<endl;
    			cin>>id;

    			if(!fi)
				    {
				    	cout<<"file couldn't be opened. product ID not found. \n";
					}
					cout<<"Modify employee name : ";
				  	cin>>name;
				  	cout<<"\nEModify Family name : ";
					cin>>f_name;
					cout<<"\nModify Phone Number : ";
					cin>>phone;
					cout<<"\nModify Salary : ";
					cin>>salary;
					cout<<"\nModify ID : ";
					cout<<rand_update(99999, 1000000);
				  	fi<<"\nName : "<<name<< "\nFamily name : "<<f_name<<"\nPhone Number : "<<phone<<"\nSalary : "<<salary<<"\nID"<<rand_update(99999, 1000000)<<endl;
				fi.close();
				 	system("cls");

				break;
			}
			default:
				{
				cout<<"Invalid Option !!!"<<endl;
				break;
				}
	}
	
	system("cls");
}

void Remove_by_ID()
{
	ofstream gfile;
	gfile.open("Check IN.txt",ios::in|ios::trunc);
	gfile.close();	
}

int main()
{

//	start();
	
	system("color F0");
	
	int a;
	class HotelMgnt hm;
	int i,j,rno;
	char ch;
	char pname[100];
	cout<<"1 : Costumer"<<endl;
	cout<<"2 : Employee"<<endl;
	cout<<"3 : Manager"<<endl;
	cout<<"\n*********************************"<<endl;
	cout<<"Please Enter your choice :";
	cin>>a;
	
	system("cls");
	
	switch(a)
	{
		case 1:
			{
				int az;
				cout<<"1 : Rooms Alloted "<<endl;
				cout<<"2 : Book a room "<<endl;
				cout<<"3 : Modify record Customer"<<endl;
				cout<<"4 : Dispaly Information "<<endl;
				cout<<"5 : Exit"<<endl;
				cout<<"Please Enter your choice :";
				cin>>az;
				
				system("cls");
				
				switch(az)
				{
					case 1:
						{
							if(count==0)
								{
									cout<<"\nRooms data is not available.\nPlease add the rooms first.";
									getch();
								}
							else
								{
									hm.getAvailRoom();
								}
							break;
						}
					case 2:
						{
							if(count==0)
								{
									cout<<"\nRooms data is not available.\nPlease add the rooms first.";
									getch();
								}
								else
								{
									hm.checkIn();
								}
							break;
						}
					case 3:
						{
							hm.Edit_Record();
							break;
						}
					case 4:
						{
							if(count==0)
								{
									cout<<"\nCustomers are not available.\nPlease add the Customers first.";
									getch();
								}
							else
								{
									cout<<"Enter Customer Name: ";
									cin>>pname;
									hm.searchCustomer(pname);
								}
							break;
						}
					case 5:
						{
							main();
						}
					default:
						{
							cout<<"Please Enter a Valid option !!! "<<endl;
							break;
						}
				}
				break;
			}
		case 2:
			{
				cout<<"//*************************************************//"<<endl;
				cout<<"Login menu"<<endl;//for reception
				int choice;
				cout<<"1: Register\n2: Login\n3: Forgot password\nYour choice: ";
				cin>>choice;
				system("cls");
					switch(choice)
					{
						case 1:
							{
								string username,password;
								cout<<"Enter a username: ";
								cin>>username;
								cout<<"Enter a password: ";
								cin>>password;
			
								ofstream file;
								file.open("Login.txt",ios::in|ios::app|ios::out);
								file<<username<<endl<<password<<endl;
								file.close();
			
								cout<<"Username: "<<username<<endl<<"Password: "<<password<<endl;
								
								system("cls");
								break;
							}
						case 2:
							{
								bool status = IsloggedIn();
			
								if (!status)
									{
										cout<<"Fals Login!"<<endl;
										bool status = IsloggedIn();
									}
								else
									{
										cout<<"Successfully logged In!"<<endl;
										
										system("cls");
										
										int ab;
										cout<<"***********************************"<<endl;
										cout<<"1 : Available Rooms"<<endl;
										cout<<"2 : Display Customer Information"<<endl;
										cout<<"3 : Check-In-Guest Room"<<endl;
										cout<<"4 : Check-Out Room"<<endl;
										cout<<"5 : Modify record Guest"<<endl;
										cout<<"6 : Check-Out-Guest Room"<<endl;
										cout<<"7 : Remove by Booking ID"<<endl;
										cout<<"8 : Exit"<<endl;
										cout<<"Enter your choice ... "<<endl;
										cin>>ab;
										
										system("cls");
				
										switch(ab)
											{
												case 1:
													{
														if(count==0)
															{
																cout<<"\nRooms data is not available.\nPlease add the rooms first.";
																getch();
															}
														else
															{
																hm.getAvailRoom();
															}
													break;
													}
												case 2:
													{
														if(count==0)
															{
																cout<<"\nCustomers are not available.\nPlease add the Customers first.";
																getch();
															}
														else
															{
																cout<<"Enter Customer Name: ";
																cin>>pname;
																hm.searchCustomer(pname);
															}
													break;
													}
												case 3:
													{
														if(count==0)
														{
															cout<<"\nRooms data is not available.\nPlease add the rooms first.";
															getch();
														}
														else
														{
															hm.checkInG();
														}
														break;
													}
												case 4:
													{
														if(count==0)
														{
															cout<<"\nRooms data is not available.\nPlease add the rooms first.";
															getch();
														}
														else
														{
															cout<<"Enter Room Number : ";
															cin>>rno;
															hm.checkOut(rno);
														}
														break;
													}
												case 5:
													{
														hm.Edit_Record_Guest();
														break;
													}
												case 6:
													{
														if(count==0)
														{
															cout<<"\nRooms data is not available.\nPlease add the rooms first.";
															getch();
														}
														else
														{
															cout<<"Enter Room Number : ";
															cin>>rno;
															hm.checkOutG(rno);
														}
														break;
													}
												case 7:
													{
														Remove_by_ID();	
																																									
													}
												case 8:
													{
														main();
													}
												default:
													{
														cout<<"Not a Good Choice..."<<endl;
														main();
														break;
													}
												break;
											}
									}
								break;
							}
						case 3:
							{
								forgot();
								break;
							}
						default:
							{
								cout<<"not a good choice"<<endl;
								break;
							}
					}		
			}
		case 3:
			{
				Employee a;
				int opt;
				system("cls");
				cout<<"######## Hotel Management #########\n";
				cout<<"\n1. Manage Rooms";
				cout<<"\n2. Add new employee";
				cout<<"\n3. Employee Managment";
				cout<<"\n4. Salary";
				cout<<"\n5. Exit";
				cout<<"\nPlease enter your choice...";
				cin>>opt;
				
				system("cls");
				
				switch(opt)
				{
					
					case 1:
						{
								class Room room;
									int opt,rno,i,flag=0;
									char ch;
									do
									{
										system("cls");
										cout<<"\n### Manage Rooms ###";
										cout<<"\n1. Add Room";
										cout<<"\n2. Back to Main Menu";
										cout<<"\n\nEnter Option: ";
										cin>>opt;
										system("cls");	
										//switch statement
										
										switch(opt)
										{
										case 1:
											{
												cout<<"\nEnter Room Number: ";
												cin>>rno;
												i=0;
												for(i=0;i<count;i++)
													{
														if(rooms[i].roomNumber==rno)
														{	
															flag=1;
														}
													}
												if(flag==1)
													{				
														cout<<"\nRoom Number is Present.\nPlease enter unique Number";
														flag=0;
														getch();
													}
												else
													{
														rooms[count]=room.addRoom(rno);
														count++;
													}
													break;
											}
										case 2:
											{
												main();
												break;
											}
								
										default:
											{
												cout<<"\nPlease Enter correct option";
												break;
											}
								
										}
									}
								while(opt!=3);
							break;
						}
					case 2:
						{
							a.get_sataff();
							break;
						}
					case 3:
						{
							int x;
							cout<<"\n 1 : Update Employee Information ";
							cout<<"\n 2 : Show List of Employee ";
							cout<<"\n 3 : Exit ";
							cout<<"\nPlease Enter a Good Choice ... "<<endl;
							cin>>x;
							
							system("cls");
							
							switch(x)
							{
								case 1:
									{
										a.update_emp();
										break;
									}
								case 2:
									{
										int b;
										cout<<" 1 : Reception"<<endl;
										cout<<" 2 : Security"<<endl;
										cout<<" 3 : Cleaning"<<endl;
										cout<<"Please enter your rule"<<endl;
										cin>>b;

										switch (b)
											{
												case 1:
													{
											  			string line;
					                           			ifstream file ("Receptions.txt");
														if(file.is_open())
															{
												   				int counter=0;
																while(getline(file,line))
																	{
													    				if(counter%5==0)
																			{
													        					counter=0;
													       						cout<<"###### Reception ######"<<endl;
													   						 }
					                               						 cout<<line<<endl;
					                                					counter++;
																	}
																		file.close();
															}
															else
																{
																	cout<<"Not found file"<<endl;
																}
														break;
													}
												case 2:
													{
											    		string l;
					                            		ifstream f ("Security.txt");
														if(f.is_open())
															{
												    			int count=0;
																while(getline(f,l))
																	{
													   					 if(count%5==0)
																			{
													       						 count=0;
													       						 cout<<"###### Security ######"<<endl;
													   						 }
					                                					cout<<l<<endl;
					                               						 count++;
																	}
																f.close();
															}
																else
																	{
																		cout<<"Not found file"<<endl;
																	}
												
															break;
													}
												case 3:
													{
											    		string li;
					                            		ifstream fi ("Cleaning.txt");
														if(fi.is_open())
															{
												   				 int counte=0;
																while(getline(fi,li))
																	{
													   					 if(counte%5==0)
																			{
													        					counte=0;
													        					cout<<"###### Cleaning ######"<<endl;
													    					}
					                               					 cout<<li<<endl;
					                               					 counte++;
																	}
																fi.close();
															}
																else
																{
																	cout<<"Not found file"<<endl;
																}
												
														break;
													}
													default:
													{
														cout<<"Not valid option !!! "<<endl;
													}										
											break;
										}
													case 3:
														{
															main();
															break;
														}
													default:
														{
															cout<<"\nNot a Good choice ... ";
															break;
														}
												}	
							break;
						
						}
					}
					case 4:
						{
							hm.guestSummaryReport();
							break;
						}
					case 5:
						{
							main();
							break;
						}
					default:
						{
							cout<<"Not valid input"<<endl;
							break;
						}
				}
			}
	}
}
